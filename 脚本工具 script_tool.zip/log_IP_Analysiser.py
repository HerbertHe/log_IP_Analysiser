#!/usr/bin/python3
# -*- coding:UTF-8 -*-

import re
import json
import os

print(" ————————————————————————————————————————")
print("\n")
print("           欢迎使用log分析脚本v1.1 （基于Python3）")
print("\n")
print("     1.本脚本用于log文件中的IP提取分析,请将文件的扩展名修改为txt")
print("     2.分析的结果保存在脚本目录下的JSON文件Analysis_Result.json中")
print("     3.分析的结果文件在每一次执行本脚本后会被覆盖，如有需要请自行修改文件名备份")
print("     4.作者GitHub主页：https://github.com/HerbertHe")
print("\n")
print(" ————————————————————————————————————————")

result = []
file_name = input("请输入需要分析的完整的文件路径或者文件名(与脚本同一文件夹下可用)\n")
os.system("cls")
go_count = 0
with open(file_name) as f:
    print("您所分析的文件为：", f.name)
    for line in f.readlines():
        result2 = re.findall('[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}', line)
        if not result2 == []:
            t = '\n'.join(result2)
            go_count = go_count+1
            result.append(t)

result_set = set(result)
ip_count = len(result_set)
result_join = '\n'.join(result_set)
print("本次提取的IP数目为：" + str(go_count))
print("本次提取的不重复IP数目为：" + str(ip_count))

all_result = "本次提取的IP数目为：" + str(go_count) + "\n" + "本次提取的不重复IP数目为：" + str(ip_count) + "\n\n" + "IP如下：\n" + result_join
with open('Analysis_Result.json', 'w') as ip:
    json.dump(all_result, ip)


def open_file():
    with open('Analysis_Result.json') as ipp:
        print(json.load(ipp))


print("\n")
print("您是否想查看完整的提取结果？yes/no")
print("如果您键入no，本程序将自行退出")
ask = input()
os.system("cls")
if ask == 'yes':
    open_file()
    os.system("pause")

elif ask == 'no':
    os.system(exit(0))

else:
    os.system("pause")
