import json
import os

file_name = input("请输入您所需要解码的完整的文件路径或文件名（跟脚本在同一文件夹下可用）\n")
os.system("cls")
with open(file_name) as f:
    print(json.load(f))
print("\n")
os.system("pause")
